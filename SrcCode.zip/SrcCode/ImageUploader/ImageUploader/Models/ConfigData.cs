﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ImageUploader.Models
{
    public class ConfigData
    {

        public const string HeadingSettings = "MySettings";
        public string Heading { get; set; }

    }
}
